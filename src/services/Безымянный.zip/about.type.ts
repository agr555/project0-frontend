export type AboutType = {
  title1: {
    ru: string,
    en: string,
    sk: string,
  },
  my:   {
    ru: string,
    en: string,
    sk: string,
  },
  subTitle:  {
    ru: string,
    en: string,
    sk: string,
  },
  text1: {
    ru: string,
    en: string,
    sk: string,
  },
  text2:  {
    ru: string,
    en: string,
    sk: string,
  },

}
