export type LangType = {

    ru:  string,
    en:  string,
    sk: string,

}
