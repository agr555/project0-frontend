import {Component, Input, OnInit} from '@angular/core';
import config from "../../config/config";
import {AboutType} from "../../types/about.type";
import {UtilityService} from "../../services/utility.service";
import {LangType} from "../../types/lang.type";
import {LangEnum} from "../../types/lang.enum";

@Component({
  selector: 'about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.scss']
})
export class AboutComponent implements OnInit {
  aboutItem: AboutType = config.about;
  title2:  LangType = config.about.title1;
  language = "en";
  currency = "$";
  data1=[];
  data2=[];
  labels1=[];
  labels2=[];
  constructor(private utiliteService: UtilityService) { }

  ngOnInit(): void {
    console.log(config.about);
  }
  changeCurrency() {
    let newCurrency = "₽";
    let coefficient = 1;
    if (this.currency === "$") {
      newCurrency = "₽";
      coefficient = 80;
    } else if (this.currency === "₽") {
      newCurrency = "BYN";
      coefficient = 3;
    } else if (this.currency === 'BYN') {
      newCurrency = '€';
      coefficient = 0.9;
    } else if (this.currency === '€') {
      newCurrency = '¥';
      coefficient = 6.9;
    }
    this.currency = newCurrency;
    console.log(this.currency)
  }
  changeLanguage() {
    let newLang = "en";
    if (this.language === "ru") {
      newLang = "sk";
    } else if (this.language  === "sk") {
      newLang = "en";
    } else if (this.language  === "en") {
      newLang = "ru";
    }
    this.language  = newLang;
    console.log(this.language)
  }
  changeInfo(val:object){
    val.hasOwnProperty('en')
    console.log(val.hasOwnProperty('en'));
  }
  _name = config.about.title1;//'Variable Example';
  get_name(title1:string){
    console.log(this._name);
    // return this._name.title1;
  }

  set name(value:LangType) {
    this._name = value;
  }
  genderCode=0;
  male() {this.genderCode = 0;}
  female() {this.genderCode = 1;}
  other() {this.genderCode = 2;}

    langCode = 0;
    langCodeStr = '';
    ru()
    {
      this.langCode = 0;
    }
    sk()
    {
      this.langCode = 1;
    }
    en()
    {
      this.langCode = 2;
    }

    ru1()
    {
      this.langCodeStr = this.aboutItem.text1.ru
      console.log(this.langCodeStr)
    }
    sk1()
    {
      this.langCodeStr = this.aboutItem.text1.sk;
      // console.log(this.langCodeStr);

      console.log('-------');
      console.log(this.language);
      let str = this.language;
      this.data1 = Object.values(this.aboutItem) as any;
      this.data2 = Object.values(this.aboutItem) as any;;
      this.labels1 = Object.keys(this.aboutItem) as any;
      this.labels2 = Object.keys(this.aboutItem) as any;
      str='text1'
      // console.log(this.aboutItem["str"]["ru"]);
      console.log(this.data1);
      console.log(this.data2);
      console.log(this.labels1);
      console.log(this.labels2);
    }
    en1()
    {
      this.langCodeStr = this.aboutItem.text1.en
      console.log(this.langCodeStr);
    }

}
